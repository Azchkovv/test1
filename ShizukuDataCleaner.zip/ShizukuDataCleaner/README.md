# Shizuku Data Cleaner

An Android app that deletes everything under `/data` **except** a hardcoded whitelist, using **Shizuku** (shell UID 2000) — no root required.

## ⚠️ Critical Limitations

Shizuku runs as the **shell user (UID 2000)**. Even with Shizuku, the following paths are protected by SELinux on Android 11+ and **cannot be deleted**:

- `/data/data/*` — app private data (sandboxes)
- `/data/system/*` — system settings
- `/data/misc/keystore/*` — keystore
- `/data/vendor/*` — vendor partitions (partially)

The app will **skip** these and log a warning. It **can** delete:

- `/data/local/tmp/*`
- `/data/app/*` (APK files)
- `/data/misc/*` (except keystore)
- `/data/tombstones/*`
- `/data/anr/*`
- `/data/dalvik-cache/*`
- `/data/resource-cache/*`
- Any custom directory you create with shell access.

## Features

- **Dry-run mode (mandatory)** — scans and lists files without deleting.
- **Whitelist** — hardcoded in `Whitelist.kt`, fully editable.
- **Shizuku UserService** — runs shell commands with shell identity.
- **Compose UI** — simple, clean, with live log output.
- **No root required** — works on non-rooted devices with Shizuku.

## Setup

### 1. Install Shizuku

Download from [shizuku.rikka.app/download](https://shizuku.rikka.app/download/).

Start Shizuku via ADB (Android 11+ supports wireless debugging):

```bash
adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh
```

Or use the Shizuku app's built-in start button (Android 11+).

### 2. Build the APK

```
./gradlew assembleDebug
```

Install on your device:

```
adb install app/build/outputs/apk/debug/app-debug.apk
```

### 3. Grant Shizuku permission

Open the app, tap **Request Shizuku Permission**, and allow it in the Shizuku dialog.

### 4. Run dry-run first

Tap **Scan (Dry Run)**. Review the list. Then tap **Execute Deletion** to actually delete.

## Configuration

Edit `Whitelist.kt` to add/remove protected paths:

```
object Whitelist {
    val paths = setOf(
        "/data/local/tmp",
        "/data/app",
        // add your own
    )
}
```

Paths are matched by prefix (recursive).

## Project Structure

```
app/src/main/
├── aidl/com/example/shizukudatacleaner/IUserService.aidl
├── java/com/example/shizukudatacleaner/
│   ├── MainActivity.kt
│   ├── ShizukuManager.kt
│   ├── UserService.kt
│   ├── CleanerEngine.kt
│   └── Whitelist.kt
├── res/values/strings.xml
└── AndroidManifest.xml
```

## License

MIT — use at your own risk. This tool deletes data. Always dry-run first.

</BDS:create_file>

<BDS:create_file fileName="ShizukuDataCleaner/settings.gradle.kts">

```kotlin
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "ShizukuDataCleaner"
include(":app")

