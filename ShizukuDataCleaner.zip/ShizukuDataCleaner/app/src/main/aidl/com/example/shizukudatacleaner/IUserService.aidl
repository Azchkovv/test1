// IUserService.aidl
package com.example.shizukudatacleaner;

interface IUserService {
    String executeCommand(String command);
    String getShellUid();
    void destroy();
}
