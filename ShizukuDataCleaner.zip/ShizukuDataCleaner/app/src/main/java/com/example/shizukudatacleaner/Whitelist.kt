package com.example.shizukudatacleaner

/**
 * Hardcoded whitelist. Paths are matched by prefix (recursive).
 * Edit this to control what is protected from deletion.
 */
object Whitelist {
    val paths: Set<String> = setOf(
        // --- PROTECTED BY DEFAULT ---
        "/data/local/tmp",          // shell scratch space
        "/data/app",                // installed APKs
        "/data/misc/keystore",      // keystore (critical)
        "/data/system",             // system settings (will fail anyway)
        "/data/data",               // app sandboxes (will fail anyway)
        "/data/vendor",             // vendor data (mostly protected)
        "/data/adb",                // Magisk / ADB modules
        "/data/dalvik-cache",       // dalvik cache (can be deleted, but keep safe)
        "/data/resource-cache",     // resource cache
        "/data/property",           // system properties
        "/data/server_configurable_flags",
        "/data/backup",             // backup staging
        "/data/media",              // internal storage mirror
        "/data/ota",                // OTA updates
        "/data/ota_package",

        // --- ADD YOUR OWN WHITELIST HERE ---
        // "/data/my_safe_folder",
    )

    /** Returns true if [path] is inside a whitelisted directory (or equals it). */
    fun isWhitelisted(path: String): Boolean {
        val normalized = path.trimEnd('/')
        return paths.any { whitelisted ->
            normalized == whitelisted || normalized.startsWith("$whitelisted/")
        }
    }
}
