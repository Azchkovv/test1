package com.example.shizukudatacleaner

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Scans /data and builds a list of files/dirs to delete,
 * respecting the whitelist. Uses Shizuku UserService for shell commands.
 */
object CleanerEngine {

    private const val TAG = "CleanerEngine"
    private const val ROOT = "/data"

    data class CleanResult(
        val scanned: Int,
        val toDelete: List<String>,
        val skipped: List<String>,
        val errors: List<String>,
        val log: List<String>
    )

    /**
     * Scan /data recursively (limited depth) and return what would be deleted.
     * Does NOT delete anything.
     */
    suspend fun dryRun(userService: IUserService, maxDepth: Int = 6): CleanResult =
        withContext(Dispatchers.IO) {
            val log = mutableListOf<String>()
            val toDelete = mutableListOf<String>()
            val skipped = mutableListOf<String>()
            val errors = mutableListOf<String>()

            log.add("Starting dry-run scan of $ROOT (max depth $maxDepth)")

            // Use find with maxdepth to avoid infinite recursion
            val cmd = "find $ROOT -maxdepth $maxDepth -mindepth 1 2>/dev/null"
            val output = userService.executeCommand(cmd)

            if (output.startsWith("ERROR")) {
                errors.add(output)
                return@withContext CleanResult(0, emptyList(), emptyList(), errors, log)
            }

            val lines = output.lines()
                .filter { it.isNotBlank() && !it.startsWith("EXIT:") && !it.startsWith("STDOUT:") && !it.startsWith("STDERR:") }

            log.add("Found ${lines.size} entries")

            for (path in lines) {
                val trimmed = path.trim()
                if (trimmed.isEmpty()) continue

                if (Whitelist.isWhitelisted(trimmed)) {
                    skipped.add(trimmed)
                    continue
                }

                // Skip known protected paths (SELinux)
                if (isSelinuxProtected(trimmed)) {
                    skipped.add(trimmed)
                    log.add("SKIP (SELinux): $trimmed")
                    continue
                }

                toDelete.add(trimmed)
            }

            log.add("Dry-run complete: ${toDelete.size} to delete, ${skipped.size} skipped, ${errors.size} errors")

            CleanResult(
                scanned = lines.size,
                toDelete = toDelete.sorted(),
                skipped = skipped.sorted(),
                errors = errors,
                log = log
            )
        }

    /**
     * Actually delete the given paths using Shizuku shell.
     * Uses `rm -rf` for each path (recursive, force).
     */
    suspend fun executeDeletion(
        userService: IUserService,
        paths: List<String>
    ): CleanResult = withContext(Dispatchers.IO) {
        val log = mutableListOf<String>()
        val errors = mutableListOf<String>()
        val deleted = mutableListOf<String>()

        log.add("Starting deletion of ${paths.size} paths")

        for (path in paths) {
            if (Whitelist.isWhitelisted(path)) {
                log.add("SKIP (whitelist): $path")
                continue
            }

            val result = userService.executeCommand("rm -rf \"$path\" 2>&1")
            if (result.contains("Permission denied") || result.contains("Operation not permitted")) {
                errors.add("$path: $result")
                log.add("FAIL: $path")
            } else {
                deleted.add(path)
                if (deleted.size % 50 == 0) {
                    log.add("Deleted ${deleted.size} / ${paths.size}")
                }
            }
        }

        log.add("Deletion complete: ${deleted.size} deleted, ${errors.size} errors")

        CleanResult(
            scanned = paths.size,
            toDelete = deleted,
            skipped = emptyList(),
            errors = errors,
            log = log
        )
    }

    /** Returns true if the path is likely protected by SELinux on Android 11+. */
    private fun isSelinuxProtected(path: String): Boolean {
        return path.startsWith("/data/data/") ||
                path == "/data/data" ||
                path.startsWith("/data/system") ||
                path.startsWith("/data/misc/keystore") ||
                path.startsWith("/data/misc/gatekeeper") ||
                path.startsWith("/data/misc/keychain") ||
                path.startsWith("/data/vendor/") && !path.startsWith("/data/vendor/tombstones")
    }
}
