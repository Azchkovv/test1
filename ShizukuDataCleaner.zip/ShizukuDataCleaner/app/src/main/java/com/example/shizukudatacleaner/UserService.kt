package com.example.shizukudatacleaner

import android.content.Context
import android.util.Log
import androidx.annotation.Keep
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Runs inside Shizuku's privileged process (shell UID 2000).
 * Receives shell commands and returns output.
 */
class UserService : IUserService.Stub() {

    @Keep
    constructor(context: Context) {
        Log.i(TAG, "UserService constructed with context: $context")
    }

    override fun executeCommand(command: String): String {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("sh", "-c", command))
            val output = BufferedReader(InputStreamReader(process.inputStream)).readText()
            val error = BufferedReader(InputStreamReader(process.errorStream)).readText()
            val exitCode = process.waitFor()

            buildString {
                appendLine("EXIT:$exitCode")
                if (output.isNotBlank()) {
                    appendLine("STDOUT:")
                    appendLine(output)
                }
                if (error.isNotBlank()) {
                    appendLine("STDERR:")
                    appendLine(error)
                }
            }.trim()
        } catch (e: Exception) {
            "ERROR: ${e.message}"
        }
    }

    override fun getShellUid(): String {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("id"))
            BufferedReader(InputStreamReader(process.inputStream)).readText().trim()
        } catch (e: Exception) {
            "ERROR: ${e.message}"
        }
    }

    override fun destroy() {
        Log.i(TAG, "UserService destroyed")
        System.exit(0)
    }

    companion object {
        private const val TAG = "ShizukuUserService"
    }
}
