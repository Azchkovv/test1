package com.example.shizukudatacleaner

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import android.os.RemoteException
import android.util.Log
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper

object ShizukuManager {
    private const val TAG = "ShizukuManager"
    const val REQUEST_CODE = 1001

    private var userService: IUserService? = null
    private var isBound = false

    /** Check if Shizuku is installed and running. */
    fun isAvailable(context: Context): Boolean {
        return try {
            context.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0)
            Shizuku.pingBinder()
        } catch (e: Exception) {
            Log.w(TAG, "Shizuku not available: ${e.message}")
            false
        }
    }

    /** Check if we already have permission. */
    fun hasPermission(): Boolean {
        return try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Exception) {
            false
        }
    }

    /** Request Shizuku permission. Returns immediately; result comes via listener. */
    fun requestPermission() {
        try {
            Shizuku.requestPermission(REQUEST_CODE)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to request permission: ${e.message}")
        }
    }

    /** Bind to the Shizuku UserService. */
    fun bindUserService(context: Context, onConnected: (IUserService) -> Unit, onDisconnected: () -> Unit) {
        val component = ComponentName(context.packageName, UserService::class.java.name)
        val args = Shizuku.UserServiceArgs(component)
            .daemon(false)
            .processNameSuffix("shizuku_service")
            .debuggable(false)
            .version(1)

        val connection = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
                Log.i(TAG, "UserService connected")
                userService = IUserService.Stub.asInterface(service)
                isBound = true
                onConnected(userService!!)
            }

            override fun onServiceDisconnected(name: ComponentName?) {
                Log.w(TAG, "UserService disconnected")
                userService = null
                isBound = false
                onDisconnected()
            }
        }

        try {
            Shizuku.bindUserService(args, connection)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to bind UserService: ${e.message}")
            onDisconnected()
        }
    }

    /** Get the bound UserService, or null. */
    fun getUserService(): IUserService? = userService

    /** Unbind (call in onDestroy). */
    fun unbind() {
        if (isBound) {
            try {
                Shizuku.unbindUserService(
                    Shizuku.UserServiceArgs(
                        ComponentName(
                            "com.example.shizukudatacleaner",
                            UserService::class.java.name
                        )
                    ),
                    true
                )
            } catch (_: Exception) {}
            isBound = false
            userService = null
        }
    }
}
