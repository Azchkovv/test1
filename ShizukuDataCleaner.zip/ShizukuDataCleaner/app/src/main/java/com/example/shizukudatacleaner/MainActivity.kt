package com.example.shizukudatacleaner

import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku
import com.example.shizukudatacleaner.ui.theme.ShizukuDataCleanerTheme

class MainActivity : ComponentActivity() {

    private val scope = CoroutineScope(Dispatchers.Main)
    private var userService: IUserService? by mutableStateOf(null)
    private var isConnected by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Shizuku permission listener
        Shizuku.addRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == ShizukuManager.REQUEST_CODE) {
                val granted = grantResult == PackageManager.PERMISSION_GRANTED
                Log.i("MainActivity", "Shizuku permission result: $granted")
                if (granted) {
                    bindService()
                }
            }
        }

        setContent {
            ShizukuDataCleanerTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    CleanerScreen(
                        onRequestPermission = { ShizukuManager.requestPermission() },
                        onBindService = { bindService() },
                        isConnected = isConnected,
                        userService = userService,
                        scope = scope
                    )
                }
            }
        }
    }

    private fun bindService() {
        val context = this
        ShizukuManager.bindUserService(
            context,
            onConnected = {
                userService = it
                isConnected = true
            },
            onDisconnected = {
                userService = null
                isConnected = false
            }
        )
    }

    override fun onDestroy() {
        super.onDestroy()
        ShizukuManager.unbind()
    }
}

@Composable
fun CleanerScreen(
    onRequestPermission: () -> Unit,
    onBindService: () -> Unit,
    isConnected: Boolean,
    userService: IUserService?,
    scope: CoroutineScope
) {
    val context = LocalContext.current

    var logText by remember { mutableStateOf("") }
    var isScanning by remember { mutableStateOf(false) }
    var isDeleting by remember { mutableStateOf(false) }
    var dryRunResult by remember { mutableStateOf<CleanerEngine.CleanResult?>(null) }

    val shizukuAvailable = remember { ShizukuManager.isAvailable(context) }
    val hasPermission = remember { ShizukuManager.hasPermission() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            "Shizuku Data Cleaner",
            style = MaterialTheme.typography.headlineMedium
        )

        // Status card
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("Shizuku: ${if (shizukuAvailable) "✅ Available" else "❌ Not found"}")
                Text("Permission: ${if (hasPermission) "✅ Granted" else "❌ Not granted"}")
                Text("UserService: ${if (isConnected) "✅ Connected" else "❌ Disconnected"}")
            }
        }

        // Action buttons
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = onRequestPermission,
                enabled = shizukuAvailable && !hasPermission,
                modifier = Modifier.weight(1f)
            ) {
                Text("Request Permission")
            }
            Button(
                onClick = onBindService,
                enabled = shizukuAvailable && hasPermission && !isConnected,
                modifier = Modifier.weight(1f)
            ) {
                Text("Connect Service")
            }
        }

        // Dry run
        Button(
            onClick = {
                scope.launch {
                    isScanning = true
                    logText = ""
                    try {
                        val service = userService ?: return@launch
                        val result = CleanerEngine.dryRun(service)
                        dryRunResult = result
                        logText = result.log.joinToString("\n")
                    } catch (e: Exception) {
                        logText = "Error: ${e.message}"
                    } finally {
                        isScanning = false
                    }
                }
            },
            enabled = isConnected && !isScanning && !isDeleting,
            modifier = Modifier.fillMaxWidth()
        ) {
            if (isScanning) CircularProgressIndicator(modifier = Modifier.size(20.dp))
            else Text("🔍 Scan (Dry Run)")
        }

        // Execute
        Button(
            onClick = {
                scope.launch {
                    isDeleting = true
                    logText = ""
                    try {
                        val service = userService ?: return@launch
                        val result = dryRunResult ?: return@launch
                        if (result.toDelete.isEmpty()) {
                            logText = "Nothing to delete."
                            return@launch
                        }
                        val deleteResult = CleanerEngine.executeDeletion(service, result.toDelete)
                        logText = deleteResult.log.joinToString("\n")
                    } catch (e: Exception) {
                        logText = "Error: ${e.message}"
                    } finally {
                        isDeleting = false
                    }
                }
            },
            enabled = isConnected && dryRunResult != null && !isScanning && !isDeleting,
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.error
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            if (isDeleting) CircularProgressIndicator(modifier = Modifier.size(20.dp))
            else Text("🗑️ Execute Deletion")
        }

        // Summary
        dryRunResult?.let { result ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Scan Summary", style = MaterialTheme.typography.titleMedium)
                    Text("Entries found: ${result.scanned}")
                    Text("To delete: ${result.toDelete.size}")
                    Text("Skipped (whitelist/SELinux): ${result.skipped.size}")
                    Text("Errors: ${result.errors.size}")
                }
            }
        }

        // Log
        if (logText.isNotBlank()) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Log", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = logText,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        modifier = Modifier.verticalScroll(rememberScrollState())
                    )
                }
            }
        }
    }
}
