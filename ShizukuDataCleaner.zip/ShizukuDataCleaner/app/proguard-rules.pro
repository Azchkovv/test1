# Shizuku
-keep class rikka.shizuku.** { *; }
-keep class moe.shizuku.** { *; }
-keep class com.example.shizukudatacleaner.IUserService { *; }
-keep class com.example.shizukudatacleaner.UserService { *; }
